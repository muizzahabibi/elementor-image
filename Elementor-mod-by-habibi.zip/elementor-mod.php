<?php
/**
 * Plugin Name:     Elementor Mod By Habibi
 * Plugin URI:      https://www.zahiradigital.id/
 * Description:     Berisi ratusan template elementor, yang akan diupdate terus
 * Author:          Habibi - Zahiradigital.id
 * Author URI:      https://www.zahiradigital.id/
 * Text Domain:     elementor-mod-habibi
 * Domain Path:     /languages
 * Version:         0.1.0
 *
 * @package         Elementor_Mod
 */

// Your code starts here.

/**
 * Register our custom source.
 */
add_action( 'elementor/init', function() {
	include 'includes/source.php';
	
	// Unregister source with closure binding, thank Steve.
	$unregister_source = function($id) {
		unset( $this->_registered_sources[ $id ] );
	};

	$unregister_source->call( \Elementor\Plugin::instance()->templates_manager, 'remote');
	\Elementor\Plugin::instance()->templates_manager->register_source( 'Elementor\TemplateLibrary\Source_Custom' );
}, 15 );
